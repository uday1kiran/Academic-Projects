clear all

 [orig_img map]=imread('cameraman.tif');

[rows cols]=size(orig_img);
orig_imp=double(orig_img);
quant_multiple=1;
blocksize=8;
dct_quantizer=[16 11 10 16 24 40 51 61;...
               12 12 14 19 26 58 60 55;...
               14 13 16 24 40 57 69 56;...
               14 17 22 29 51 87 80 62;...
               18 22 37 56 68 109 103 77;...
               24 35 55 64 81 104 113 92;...
               49 64 78 87 103 121 120 101;...
               72 92 95 98 112 100 103 99];
colors=max(max(orig_img));
figure(1)
map=colormap(gray(256))
image(orig_img)
title('original image');
orig_img=orig_img-ceil(colors/2);
figure(2)
map=colormap(gray(256))
image(orig_img)
title('original substraction');
pad_cols=(1-(cols/blocksize-floor(cols/blocksize)))*blocksize;
if pad_cols==blocksize,pad_cols=0;
end
pad_rows=(1-(rows/blocksize-floor(rows/blocksize)))*blocksize;
if pad_rows==blocksize,pad_rows=0;
end
for extra_cols=1:pad_cols
    orig_img(1:rows,cols+extra_cols)=orig_img(1:rows,cols);
end
cols=cols+pad_cols%origimg is now pad_cols wider
for extra_rows=1:pad_rows
    orig_img(rows+extra_rows,1:cols)=orig_img(rows,1:cols);
end
rows=rows+pad_rows%origimg is now pad_cols taller
i=0;
for j=0:blocksize-1
    dct_trans(i+1,j+1)=sqrt(1/blocksize)*cos((2*j+1)*i*pi/(2*blocksize));
end
for i=1:blocksize-1
    for j=0:blocksize-1
        dct_trans(i+1,j+1)=sqrt(1/blocksize)*cos((2*j+1)*i*pi/(2*blocksize));
    end
end
jpeg_img=orig_img-orig_img%zero the matrix for compressed image
for row=1:blocksize:rows
    for col=1:blocksize:cols
        %take a block of the image:
        dct_matrix=orig_img(row:row+blocksize-1,col:col+blocksize-1);
        %perform the transform operation on the 2-Dblock
        dct_matrix=double(dct_matrix);
        dct_matrix=dct_trans.*dct_matrix.*dct_trans';
        %quantise it(levels stored in dct _quantiser matrix);
        dct_matrix=floor(dct_matrix/(dct_quantizer(1:blocksize,1:blocksize)*quant_multiple)+0.5);
        jpeg_img(row:row+blocksize-1,col:col+blocksize-1)=dct_matrix;
    end
end
figure(3)
map=colormap(gray(256))
imshow(jpeg_img,[]);
title('applied dct on substracted original::after dct image');
recon_img=orig_img-orig_img%zero the matrix for reconstructed image
for row=1:blocksize:rows
    for col=1:blocksize:cols
        %take ablock image;
        idct_matrix=jpeg_img(row:row+blocksize-1,col:col+blocksize-1);
        %reconstruct the quanted values:
        idct_matrix=double(idct_matrix);
        idct_matrix=idct_matrix*(dct_quantizer(1:blocksize,1:blocksize)*quant_multiple);
        %perform inverse dct;
        idct_matrix=dct_trans'.*idct_matrix.*dct_trans;
        %place it into reconstructed image:
        recon_img(row:row+blocksize-1,col:col+blocksize-1)=idct_matrix;
    end
end
figure(4)
map=colormap(gray(256))
imshow(recon_img,[]);
title('idct on dct::before addition of image');
recon_img=recon_img+ceil(colors/2);
figure(5)
map=colormap(gray(256))
imshow(recon_img,[]);
title('idct on dct::after addition of image');
orig_img=orig_img+ceil(colors/2);
figure(6)
map=colormap(gray(256))
imshow(orig_img,[]);
title('original addition of image');
rows=rows-pad_rows;
cols=cols-pad_cols;
recon_img=recon_img(1:rows,1:cols);
figure(7)
map=colormap(gray(256))
imshow(recon_img,[]);
title('decompressed image');

        


















    